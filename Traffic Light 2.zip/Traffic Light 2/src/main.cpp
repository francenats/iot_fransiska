#include <Arduino.h>

int tombol1 = 34;
int tombol2 = 35;
int tombol3 = 32;

int redlight = 23;
int yellowlight = 22;
int greenlight = 21;

// Fungsi debouncing
boolean debounce(int pin) {
  delay(50); // Delay untuk menghindari bouncing
  return digitalRead(pin) == LOW; // Kembalikan keadaan tombol setelah debounce
}

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP 32!");

  // Set pin mode untuk tombol
  pinMode(tombol1, INPUT_PULLUP);
  pinMode(tombol2, INPUT_PULLUP);
  pinMode(tombol3, INPUT_PULLUP);

  // Set pin mode untuk LED
  pinMode(redlight, OUTPUT);
  pinMode(yellowlight, OUTPUT);
  pinMode(greenlight, OUTPUT);

  // Pastikan semua LED mati di awal
  digitalWrite(redlight, LOW);
  digitalWrite(yellowlight, LOW);
  digitalWrite(greenlight, LOW);
}

void loop() {
  // Tombol 1: Lampu merah berkedip 5x
  if (debounce(tombol1)) {
    for (int i = 0; i < 5; i++) {
      digitalWrite(redlight, HIGH);
      delay(500); // Nyala selama 500 ms
      digitalWrite(redlight, LOW);
      delay(500); // Mati selama 500 ms
    }
  }

  // Tombol 2: Lampu merah dan hijau berkedip bergantian
  if (debounce(tombol2)) {
    for (int i = 0; i < 5; i++) {
      digitalWrite(redlight, HIGH);
      digitalWrite(greenlight, LOW);
      delay(500); // Merah nyala, hijau mati
      digitalWrite(redlight, LOW);
      digitalWrite(greenlight, HIGH);
      delay(500); // Merah mati, hijau nyala
    }
    digitalWrite(greenlight, LOW); // Pastikan hijau mati setelah selesai
  }

  // Tombol 3: Lampu merah, kuning, hijau berkedip bergantian
  if (debounce(tombol3)) {
    for (int i = 0; i < 5; i++) {
      digitalWrite(redlight, HIGH);
      digitalWrite(yellowlight, LOW);
      digitalWrite(greenlight, LOW);
      delay(500); // Merah nyala, kuning dan hijau mati
      digitalWrite(redlight, LOW);
      digitalWrite(yellowlight, HIGH);
      digitalWrite(greenlight, LOW);
      delay(500); // Kuning nyala, merah dan hijau mati
      digitalWrite(redlight, LOW);
      digitalWrite(yellowlight, LOW);
      digitalWrite(greenlight, HIGH);
      delay(500); // Hijau nyala, merah dan kuning mati
    }
    digitalWrite(greenlight, LOW); // Pastikan hijau mati setelah selesai
  }

  // Delay kecil untuk mengurangi bouncing tombol
  delay(100);
}