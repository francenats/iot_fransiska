#include <Arduino.h>

int red = 17;
int yellow = 18;
int green = 19;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(red, OUTPUT);
  pinMode(yellow, OUTPUT);
  pinMode(green, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(red, HIGH);
  digitalWrite(yellow, LOW);
  digitalWrite(green, LOW);
  Serial.println("Lampu Merah");
  delay(30000);
  digitalWrite(red, LOW);
  digitalWrite(yellow, HIGH);
  digitalWrite(green, LOW);
  Serial.println("Lampu Kuning");
  delay(5000);
  digitalWrite(red, LOW);
  digitalWrite(yellow, LOW);
  digitalWrite(green, HIGH);
  Serial.println("Lampu Hijau");
  delay(20000);
}
