#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// Definisi pin
#define DHTPIN 4          // Pin GPIO untuk DHT22
#define DHTTYPE DHT22     // Jenis sensor DHT
#define LDR_PIN 34        // Pin analog untuk LDR
#define SCREEN_WIDTH 128  // Lebar OLED
#define SCREEN_HEIGHT 64  // Tinggi OLED
#define OLED_RESET    -1  // Reset pin OLED

// Inisialisasi OLED
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Inisialisasi DHT
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // Inisialisasi Serial Monitor
  Serial.begin(9600);

  // Inisialisasi OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  display.display();
  delay(2000);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Initializing...");
  display.display();

  // Inisialisasi DHT
  dht.begin();
}

void loop() {
  // Baca suhu dan kelembapan dari DHT22
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  // Baca intensitas cahaya dari LDR
  int lightIntensity = analogRead(LDR_PIN);

  // Periksa apakah pembacaan DHT gagal
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  // Tampilkan data di Serial Monitor
  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" °C\t");
  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.print(" %\t");
  Serial.print("Light Intensity: ");
  Serial.println(lightIntensity);

  // Tampilkan data di OLED
  display.clearDisplay();
  display.setCursor(0, 0);
  display.print("Temp: ");
  display.print(temperature);
  display.println(" C");
  display.print("Humidity: ");
  display.print(humidity);
  display.println(" %");
  display.print("Light: ");
  display.print(lightIntensity);
  display.println(" lx");
  display.display();

  // Tunggu 2 detik sebelum membaca lagi
  delay(2000);
}